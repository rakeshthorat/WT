<?php
session_start();

// Check if the 'action' parameter is set in the URL
if (isset($_GET['action'])) {
    if ($_GET['action'] == 'start') {
        // Start the session and store user data
        $_SESSION['username'] = 'SiddhantSupe';
        $_SESSION['email'] = 'supesiddhant13@gmail.com';
        echo "Session started. <br>";
        echo "Username: " . $_SESSION['username'] . "<br>";
        echo "Email: " . $_SESSION['email'] . "<br>";
    } elseif ($_GET['action'] == 'view') {
        // Check if session variables are set
        if (isset($_SESSION['username']) && isset($_SESSION['email'])) {
            echo "Session Data: <br>";
            echo "Username: " . $_SESSION['username'] . "<br>";
            echo "Email: " . $_SESSION['email'] . "<br>";
        } else {
            echo "No session data found.<br>";
        }
    } elseif ($_GET['action'] == 'destroy') {
        // Unset all of the session variables and destroy the session
        session_unset();
        session_destroy();
        echo "Session destroyed.<br>";
    }
} else {
    echo "Welcome!<br>";
}

// Display links for session management actions
echo "<br>";
echo "<a href='?action=start'>Start Session</a> | ";
echo "<a href='?action=view'>View Session Data</a> | ";
echo "<a href='?action=destroy'>Destroy Session</a>";
?>
