<?php
$text = "Hello, World!";
echo "Original Text: " . $text . "<br>";
echo "Text Length: " . strlen($text) . "<br>";
echo "Uppercase Text: " . strtoupper($text) . "<br>";
echo "Reversed Text: " . strrev($text) . "<br>";
?>
